import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap3-sidebar',
  templateUrl: './baitap3-sidebar.component.html',
  styleUrls: ['./baitap3-sidebar.component.scss']
})
export class Baitap3SidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
