import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap3-content',
  templateUrl: './baitap3-content.component.html',
  styleUrls: ['./baitap3-content.component.scss']
})
export class Baitap3ContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
