import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap3-footer',
  templateUrl: './baitap3-footer.component.html',
  styleUrls: ['./baitap3-footer.component.scss']
})
export class Baitap3FooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
