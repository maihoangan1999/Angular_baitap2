import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap2-what-we-do',
  templateUrl: './baitap2-what-we-do.component.html',
  styleUrls: ['./baitap2-what-we-do.component.scss']
})
export class Baitap2WhatWeDoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
