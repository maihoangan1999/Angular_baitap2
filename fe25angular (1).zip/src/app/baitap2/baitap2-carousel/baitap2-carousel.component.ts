import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap2-carousel',
  templateUrl: './baitap2-carousel.component.html',
  styleUrls: ['./baitap2-carousel.component.scss']
})
export class Baitap2CarouselComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
