import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap2',
  templateUrl: './baitap2.component.html',
  styleUrls: ['./baitap2.component.scss']
})
export class Baitap2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
